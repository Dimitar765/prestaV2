<?php

if (!defined('_PS_VERSION_')) {
    exit;
}

class EcomZone extends Module
{
    public function __construct()
    {
        $this->name = 'ecomzone';
        $this->tab = 'market_place';
        $this->version = '1.0.0';
        $this->author = 'Your Name';
        $this->need_instance = 0;
        $this->bootstrap = true;

        parent::__construct();

        $this->displayName = $this->l('EcomZone Dropshipping');
        $this->description = $this->l('Integration with EcomZone Dropshipping API');
    }

    public function install()
    {
        return parent::install() &&
            $this->registerHook('actionOrderStatusUpdate') &&
            Configuration::updateValue('ECOMZONE_API_TOKEN', '') &&
            Configuration::updateValue('ECOMZONE_API_URL', 'https://dropship.ecomzone.eu/api');
    }

    public function uninstall()
    {
        return parent::uninstall() &&
            Configuration::deleteByName('ECOMZONE_API_TOKEN') &&
            Configuration::deleteByName('ECOMZONE_API_URL');
    }

    public function getContent()
    {
        if (Tools::isSubmit('submitEcomZoneModule')) {
            Configuration::updateValue('ECOMZONE_API_TOKEN', Tools::getValue('ECOMZONE_API_TOKEN'));
            $this->_clearCache('*');
        }

        $this->context->smarty->assign([
            'ECOMZONE_API_TOKEN' => Configuration::get('ECOMZONE_API_TOKEN'),
        ]);

        return $this->display(__FILE__, 'views/templates/admin/configure.tpl');
    }

    public function hookActionOrderStatusUpdate($params)
    {
        $order = $params['order'];
        $newOrderStatus = $params['newOrderStatus'];

        // Sync order when it's paid
        if ($newOrderStatus->paid == 1) {
            try {
                $orderSync = new EcomZoneOrderSync();
                $result = $orderSync->syncOrder($order->id);
                
                // Log the result
                PrestaShopLogger::addLog(
                    'EcomZone order sync: ' . json_encode($result),
                    1,
                    null,
                    'Order',
                    $order->id,
                    true
                );
            } catch (Exception $e) {
                PrestaShopLogger::addLog(
                    'EcomZone order sync error: ' . $e->getMessage(),
                    3,
                    null,
                    'Order',
                    $order->id,
                    true
                );
            }
        }
    }
} 