<?php

class EcomZoneOrderSync
{
    private $client;

    public function __construct()
    {
        $this->client = new EcomZoneClient();
    }

    public function syncOrder($orderId)
    {
        $order = new Order($orderId);
        $customer = new Customer($order->id_customer);
        $address = new Address($order->id_address_delivery);

        $orderData = [
            'order_index' => $order->id,
            'ext_id' => $order->reference,
            'payment' => [
                'method' => $this->getPaymentMethod($order),
                'customer_price' => $order->total_paid
            ],
            'customer_data' => [
                'full_name' => $customer->firstname . ' ' . $customer->lastname,
                'email' => $customer->email,
                'phone_number' => $address->phone,
                'country' => Country::getIsoById($address->id_country),
                'address' => $address->address1 . ' ' . $address->address2,
                'city' => $address->city,
                'post_code' => $address->postcode
            ],
            'items' => $this->getOrderItems($order)
        ];

        return $this->client->createOrder($orderData);
    }

    private function getPaymentMethod($order)
    {
        // Map PrestaShop payment modules to eComZone payment methods
        return $order->module === 'cashondelivery' ? 'cod' : 'pp';
    }

    private function getOrderItems($order)
    {
        $items = [];
        $products = $order->getProducts();

        foreach ($products as $product) {
            $items[] = [
                'full_sku' => $product['reference'],
                'quantity' => $product['product_quantity']
            ];
        }

        return $items;
    }
} 