<?php

class EcomZoneClient
{
    private $apiToken;
    private $apiUrl;

    public function __construct()
    {
        $this->apiToken = Configuration::get('ECOMZONE_API_TOKEN');
        $this->apiUrl = Configuration::get('ECOMZONE_API_URL');
    }

    public function getCatalog($perPage = 1000)
    {
        $url = $this->apiUrl . '/catalog';
        if ($perPage) {
            $url .= '?per_page=' . $perPage;
        }
        
        return $this->makeRequest('GET', $url);
    }

    public function getProduct($sku)
    {
        return $this->makeRequest('GET', $this->apiUrl . '/product/' . $sku);
    }

    public function createOrder($orderData)
    {
        return $this->makeRequest('POST', $this->apiUrl . '/ordering', $orderData);
    }

    public function getOrder($orderId)
    {
        return $this->makeRequest('GET', $this->apiUrl . '/order/' . $orderId);
    }

    private function makeRequest($method, $url, $data = null)
    {
        $curl = curl_init();

        $options = [
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => $method,
            CURLOPT_HTTPHEADER => [
                'Authorization: Bearer ' . $this->apiToken,
                'Content-Type: application/json',
                'Accept: application/json'
            ],
        ];

        if ($data) {
            $options[CURLOPT_POSTFIELDS] = json_encode($data);
        }

        curl_setopt_array($curl, $options);

        $response = curl_exec($curl);
        $err = curl_error($curl);

        curl_close($curl);

        if ($err) {
            throw new Exception('cURL Error: ' . $err);
        }

        return json_decode($response, true);
    }
} 