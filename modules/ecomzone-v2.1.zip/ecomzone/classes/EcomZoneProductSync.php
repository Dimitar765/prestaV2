<?php

class EcomZoneProductSync
{
    private $client;
    
    public function __construct()
    {
        $this->client = new EcomZoneClient();
    }
    
    public function importProducts($page = 1, $perPage = 100)
    {
        EcomZoneLogger::log("Starting product import - page: $page, perPage: $perPage");
        
        try {
            $catalog = $this->client->getCatalog($perPage);
            
            if (!is_array($catalog) || !isset($catalog['data']) || !is_array($catalog['data'])) {
                throw new Exception('Invalid catalog data received from API: ' . json_encode($catalog));
            }
            
            $importedCount = 0;
            foreach ($catalog['data'] as $product) {
                if ($this->importSingleProduct($product)) {
                    $importedCount++;
                }
            }
            
            $total = isset($catalog['total']) ? $catalog['total'] : count($catalog['data']);
            
            EcomZoneLogger::log("Finished importing products", 'INFO', [
                'total_imported' => $importedCount,
                'page' => $page,
                'total_available' => $total
            ]);
            
            return [
                'success' => true,
                'imported' => $importedCount,
                'total' => $total
            ];
            
        } catch (Exception $e) {
            EcomZoneLogger::log("Error importing products: " . $e->getMessage(), 'ERROR');
            throw $e;
        }
    }
    
    private function importSingleProduct($productData)
    {
        // Extract data from nested structure
        $data = isset($productData['data']) ? $productData['data'] : $productData;

        if (!isset($data['sku']) || !isset($data['product_name']) || !isset($data['description']) || !isset($data['product_price'])) {
            EcomZoneLogger::log("Invalid product data", 'ERROR', ['data' => $productData]);
            return false;
        }

        try {
            // Check if product already exists by reference
            $productId = Db::getInstance()->getValue('
                SELECT id_product 
                FROM ' . _DB_PREFIX_ . 'product 
                WHERE reference = "' . pSQL($data['sku']) . '"
            ');

            $product = $productId ? new Product($productId) : new Product();
            
            $defaultLangId = (int)Configuration::get('PS_LANG_DEFAULT');
            
            $product->reference = $data['sku'];
            $product->name[$defaultLangId] = $data['product_name'];
            $product->description[$defaultLangId] = $data['long_description'] ?? $data['description'];
            $product->description_short[$defaultLangId] = $data['description'];
            $product->price = $data['product_price'];
            $product->active = true;
            $product->quantity = (int)$data['stock'];
            
            // Save product first to get ID
            if (!$product->id) {
                $product->add();
            } else {
                $product->update();
            }

            // Handle image import if URL is provided
            if (isset($data['image']) && !empty($data['image'])) {
                $this->importProductImage($product, $data['image']);
            }
            
            StockAvailable::setQuantity($product->id, 0, (int)$data['stock']);
            
            EcomZoneLogger::log("Imported product", 'INFO', [
                'sku' => $data['sku'],
                'id' => $product->id,
                'name' => $data['product_name']
            ]);
            
            return true;
            
        } catch (Exception $e) {
            EcomZoneLogger::log("Error importing product", 'ERROR', [
                'sku' => $data['sku'],
                'error' => $e->getMessage()
            ]);
            return false;
        }
    }

    private function importProductImage($product, $imageUrl)
    {
        try {
            // Create temporary file
            $tmpFile = tempnam(_PS_TMP_IMG_DIR_, 'ecomzone_');
            
            // Download image
            if (!copy($imageUrl, $tmpFile)) {
                throw new Exception("Failed to download image from: " . $imageUrl);
            }
            
            // Get image info
            $imageInfo = getimagesize($tmpFile);
            if (!$imageInfo) {
                unlink($tmpFile);
                throw new Exception("Invalid image file");
            }
            
            // Generate unique name
            $imageName = $product->reference . '-' . time() . '.jpg';
            
            // Delete existing images if any
            $product->deleteImages();
            
            // Add new image
            $image = new Image();
            $image->id_product = $product->id;
            $image->position = 1;
            $image->cover = true;
            
            if ($image->add()) {
                $newPath = _PS_PROD_IMG_DIR_ . $image->getImgPath() . '.jpg';
                ImageManager::resize($tmpFile, $newPath);
                
                // Generate thumbnails
                $imagesTypes = ImageType::getImagesTypes('products');
                foreach ($imagesTypes as $imageType) {
                    ImageManager::resize(
                        $tmpFile,
                        _PS_PROD_IMG_DIR_ . $image->getImgPath() . '-' . $imageType['name'] . '.jpg',
                        $imageType['width'],
                        $imageType['height']
                    );
                }
            }
            
            // Cleanup
            unlink($tmpFile);
            
            EcomZoneLogger::log("Imported product image", 'INFO', [
                'sku' => $product->reference,
                'image' => $imageUrl
            ]);
            
        } catch (Exception $e) {
            EcomZoneLogger::log("Error importing product image", 'ERROR', [
                'sku' => $product->reference,
                'image' => $imageUrl,
                'error' => $e->getMessage()
            ]);
        }
    }
} 